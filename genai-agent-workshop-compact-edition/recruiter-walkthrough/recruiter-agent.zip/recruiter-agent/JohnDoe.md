# John Doe  
**Graphic Designer**  
**Email:** johndoe@example.com | **Phone:** +1 234 567 890 | **Portfolio:** [www.johndoeportfolio.com](http://www.johndoeportfolio.com)  

---

## Professional Summary  
Creative and detail-oriented Graphic Designer with 8+ years of experience in creating visually compelling designs for digital and print media. Proficient in Adobe Creative Suite, typography, and branding. Adept at collaborating with clients and cross-functional teams to deliver high-quality projects on time and within budget.

---

## Skills  
- Proficient in Adobe Photoshop, Illustrator, InDesign, and After Effects  
- Strong understanding of typography, color theory, and layout design  
- Expertise in branding, logo design, and packaging  
- Experience with UI/UX design and wireframing abilities  
- Excellent communication and project management skills  

---

## Work Experience  

### Senior Graphic Designer  
**Creative Agency XYZ** | *Jan 2018 - Present*  
- Led a team of 5 designers to develop branding and marketing materials for clients across various industries.  
- Designed and executed over 200 projects, including logos, brochures, websites, and social media campaigns.  
- Collaborated with clients to understand their vision and deliver creative solutions that exceeded expectations.  

### Graphic Designer  
**Design Studio ABC** | *Jun 2015 - Dec 2017*  
- Created visual concepts for print and digital media, including advertisements, magazines, and websites.  
- Worked closely with the marketing team to ensure designs aligned with brand guidelines.  
- Improved client satisfaction by 20% through innovative and timely design solutions.  

---

## Education  
**Bachelor of Fine Arts in Graphic Design**  
*University of Arts* | Graduated: 2015  

---

## Certifications  
- Adobe Certified Expert (ACE) in Photoshop  
- Google UX Design Professional Certificate  
- Advanced Typography and Branding Workshop  

---

## Projects  
- **Rebranding for TechCorp:** Led the rebranding project for a leading tech company, including logo design, website redesign, and marketing materials.  
- **E-commerce Website Design:** Designed a user-friendly and visually appealing e-commerce website for a fashion brand, resulting in a 30% increase in sales.  
- **Social Media Campaigns:** Developed creative assets for social media campaigns that boosted engagement by 50%.  

---

## Awards  
- Best Graphic Designer Award | Creative Agency XYZ | 2021  
- Outstanding Branding Project | Design Awards | 2020  
- Excellence in Design | University of Arts | 2015  

---

## References  
Available upon request.  

---

## Portfolio Highlights  
Visit [www.johndoeportfolio.com](http://www.johndoeportfolio.com) to view a curated selection of my work, including branding projects, digital illustrations, and UI/UX designs.